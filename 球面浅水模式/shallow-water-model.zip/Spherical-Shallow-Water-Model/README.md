# Spherical-Shallow-Water-Model

This is a simple shallow water numerical model on a spherical coordinate.

More details please click [here](https://qqfraphael.gitbooks.io/myjournal/content/2018/2018-01-28-浅水模式.html)

Usage: `python shallow_water.py`
