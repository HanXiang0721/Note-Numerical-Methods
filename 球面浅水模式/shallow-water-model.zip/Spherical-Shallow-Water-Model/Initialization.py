import numpy as np
class Initialization(object):
    def __init__(self, dt_mins, output_interval_mins, forecast_length_days, add_random_height_noise, initially_geostrophic, viscous_dissipation, vis, g, rho, Re, rotation_period, scale_height, max_wind):
        # params from namelist
        self.dt_mins                   = dt_mins
        self.output_interval_mins      = output_interval_mins
        self.forecast_length_days      = forecast_length_days
        self.add_random_height_noise   = add_random_height_noise
        self.initially_geostrophic     = initially_geostrophic
        self.viscous_dissipation       = viscous_dissipation
        self.vis                       = vis
        self.g                         = g
        self.rho                       = rho
        self.Re                        = Re
        self.rotation_period           = rotation_period
        self.scale_height              = scale_height
        self.max_wind                  = max_wind
        
        # params constructed based on namelist
        self.f                         = 2.*np.pi/(self.rotation_period*3600.)
        self.dtheta                    = 1.*np.pi/180.                                                                            # the north-south (latitude coordinate)
        self.dphi                      = 1.*np.pi/180.                                                                            # the east-west (longitude coordinate)
        self.phi                       = np.arange(0,2.*np.pi,self.dphi)                                                          # the longitude mesh 
        self.theta                     = np.arange(self.dtheta/2-85*np.pi/180,85.*np.pi/180-self.dtheta/2,self.dtheta)            # the latitude mesh
        self.THETA, self.PHI           = np.meshgrid(self.theta,self.phi)
        self.nx                        = np.size(self.phi)                                                                        # number of points in east-west direction
        self.ny                        = np.size(self.theta)                                                                      # number of points in north-south direction
        self.F                         = 2.*self.f*np.sin(self.THETA)                                                                  # Coriolis parameter
        self.dt                        = self.dt_mins*60.0                                                                        # Timestep (s)
        self.output_interval           = self.output_interval_mins*60.0                                                           # Time between outputs (s)
        self.forecast_length           = self.forecast_length_days*24.0*3600.0                                                    # Forecast length (s)
        self.nt                        = int(np.fix(self.forecast_length/self.dt)+1)                                              # Number of timesteps
        self.timesteps_between_outputs = int(np.fix(self.output_interval/self.dt))                                                # Timesteps between output interval
        self.noutput                   = int(np.ceil(self.nt/self.timesteps_between_outputs))                                     # Number of output frames
        self.x                         = self.PHI*np.cos(self.THETA)*self.Re                                                      # Grid in x direction
        self.y                         = self.THETA*self.Re                                                                       # Grid in y direction
        self.dx                        = self.dphi*np.cos(self.THETA)*self.Re                                                     # Grid space in x direction
        self.dy                        = self.dtheta*self.Re*np.ones(np.shape(self.THETA))                                        # Grid space in y direction
        self.u_save                    = np.zeros([self.nx, self.ny, self.noutput])                                               # Arrays used to save u field
        self.v_save                    = np.zeros([self.nx, self.ny, self.noutput])                                               # Arrays used to save v field
        self.h_save                    = np.zeros([self.nx, self.ny, self.noutput])                                               # Arrays used to save h field
        self.t_save                    = np.zeros([1, self.noutput])                                                              # Arrays used to save t field
        self.i_save                    = 0                                                                                        # Index to stored data
        self.idx                       = [x for x in range(self.nx-2)];self.idx.insert(self.nx-2,0);self.idx.insert(0,self.nx-3)  # Create index array for the convenience of setting boundary condition
        self.idy                       = [y for y in range(self.ny-2)];self.idy.insert(self.ny-2,0);self.idy.insert(0,self.ny-3)  # Create index array for the convenience of setting boundary condition
        self.dy1                       = self.dtheta*self.Re*np.cos(self.THETA)                                                   # For the convenience of calculation
        self.dy2                       = self.dtheta*self.Re                                                                      # For the convenience of calculation
        self.c_mid_yt                  = np.cos(0.5*(self.THETA[:,1:self.ny]+self.THETA[:,0:self.ny-1]))                          # calculate mid-point value of cos(theta)
        self.H                         = np.zeros([self.nx, self.ny])                                                             # terrain height
        self.u                         = np.zeros([self.nx, self.ny])                                                             # u wind field   
        self.v                         = np.zeros([self.nx, self.ny])                                                             # v wind field  
        self.height                    = np.zeros([self.nx, self.ny])                                                             # height is the depth of fluid
        self.h                         = np.zeros([self.nx, self.ny])                                                             # h is the depth of the fluid
        # load data
        #f = open("saturn_u.txt")
            #lines = f.readlines()
            #A_row = 0  
            #for line in lines:
            #    data = line.strip('\n').split('\t')
            #    u[A_row:] = data[0:170]
            #    A_row += 1
            #
            #f = open("saturn_v.txt")
            #lines = f.readlines()
            #A_row = 0  
            #for line in lines:
            #    data = line.strip('\n').split('\t')
            #    v[A_row:] = data[0:170]
            #    A_row += 1
        from scipy.stats import norm
        self.u = norm.pdf(self.THETA,0.*np.pi/180.,10.*np.pi/180.)
        self.u = 100.*self.u / np.max(self.u[0,:])
        self.v[:,:] = 0.
        
        # set up height field from observed winds (geostrophic balance), "height" is the height of the upper surface
        self.height[:,0] = self.scale_height
        for i in np.arange(0,self.ny-1):
                self.height[:,i+1] = self.height[:,i] - 0.5 * (self.F[:,i+1] + self.F[:,i]) * 0.5 * (self.u[:,i+1] + self.u[:,i]) * self.Re / self.g * self.dtheta
        
        # add some noise to height field
        if self.add_random_height_noise:
            self.height = self.height + 500.0 * np.random.randn(self.nx,self.ny) * (self.dtheta / (np.pi/(self.ny-1))) * (np.abs(self.F) / 3e-4) * np.cos(self.THETA)
        
        # initially geostrophic balance
        if self.initially_geostrophic:
            self.u[:,1:self.ny-1] = -0.5 * self.g *(self.height[:,2:self.ny] - self.height[:,0:self.ny-2]) / (self.Re * self.dtheta * (self.F[:,1:self.ny-1]))
            self.v[1:self.nx-1,:] = 0.5 * self.g * (self.height[2:self.nx,:] - self.height[0:self.nx-2,:]) / (self.Re * self.dphi * np.cos(self.THETA[1:self.nx-1,:]) * (self.F[1:self.nx-1,:]))
            self.v[0,:] = 0.5 * self.g * (self.height[1,:] - self.height[self.nx-1,:]) / (self.Re * self.dphi * np.cos(self.THETA[0,:]) * (self.F[0,:]))
            self.v[self.nx-1,:] = 0.5 * self.g * (self.height[0,:] - self.height[self.nx-2,:]) / (self.Re * self.dphi * np.cos(self.THETA[self.nx-1,:]) * (self.F[self.nx-1,:]))
            self.v[:,0] = 0.
            self.v[:,self.ny-1] = 0.
            self.u[:,0] = self.u[:,1]
            self.u[:,self.ny-1] = self.u[:,self.ny-2]   
            self.u[:,int(np.ceil(self.ny/2))] = self.u[:,int(np.ceil(self.ny/2)+1)]
            self.v[:,int(np.ceil(self.ny/2))] = self.v[:,int(np.ceil(self.ny/2)+1)]
            self.u[self.u>self.max_wind] = self.max_wind
            self.u[self.u<-self.max_wind] = -self.max_wind
            self.v[self.v>self.max_wind] = self.max_wind
            self.v[self.v<-self.max_wind] = -self.max_wind
        
        self.h = self.height - self.H
        
        
