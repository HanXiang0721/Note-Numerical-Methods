import numpy as np

#--------------------------------model parameters---------------------------------
dt_mins                   = 1                                                               # Timestep (minutes)
output_interval_mins      = 120                                                             # Time between outputs (minutes)
forecast_length_days      = 360                                                             # Total simulation length (days)
add_random_height_noise   = False                                                           # Add random noise to height field
initially_geostrophic     = False                                                           # Make the initial condition conform geostrophic balance
viscous_dissipation       = True                                                            # Add viscous dissipation
vis                       = 5.e6                                                            # turbulent dissipation coefficient
dynamic_core              = "lax_wendroff"                                                  # numeric scheme, lax wendroff, lax friedrichs
output                    = "mem"                                                           # put the result in a large array in the memory (mem), picture (pic) 

#--------------------------------planet parameters--------------------------------
g                         = 10.44                                                           # gravity
rho                       = 0.19                                                            # density
Re                        = 5.8232e7                                                        # radius of planet
rotation_period           = 10.656                                                          # planet's rotation rate in days
scale_height              = 60.e3                                                           # scale height of planet's atmosphere
max_wind                  = 2000                                                            # the maximum wind speed on the planet
