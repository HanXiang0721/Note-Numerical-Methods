from params import *
from Solution import Solution


if __name__ == "__main__":
	solution = Solution(dt_mins,output_interval_mins,forecast_length_days,add_random_height_noise,initially_geostrophic,viscous_dissipation,vis,g,rho,Re,rotation_period,scale_height,max_wind,dynamic_core,output)
	solution.run()
