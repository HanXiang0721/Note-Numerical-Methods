import numpy as np
from plot import myplot
from params import dynamic_core
from Initialization import Initialization
from NumericalMethods import LaxWendroffSphere, LaxFriedrichsSphere, ViscousDissipationSphere

class Solution(Initialization):
	def __init__(self, dt_mins, output_interval_mins, forecast_length_days, add_random_height_noise, initially_geostrophic, viscous_dissipation, vis, g, rho, Re, rotation_period, scale_height, max_wind, dynamic_core, output):
		super(Solution, self).__init__(dt_mins, output_interval_mins, forecast_length_days, add_random_height_noise, initially_geostrophic, viscous_dissipation, vis, g, rho, Re, rotation_period, scale_height, max_wind)
		self.dynamic_core = dynamic_core
		self.output = output

	def run(self):
		for n in np.arange(self.nt):
			if n % self.timesteps_between_outputs == 0:
				max_u = np.sqrt(np.max(self.u*self.u+self.v*self.v))
				print('Time = %s hours (total %s); max(|u|) = %s' % (n*self.dt/3600, self.forecast_length_days*24, max_u))
				if n*self.dt/3600 > 10:
					if self.output == "pic":
						self.myplot(self.nx, self.ny, self.dx, self.dy, self.u, self.v, self.h, self.phi, self.theta, self.n*self.dt/3600)
					elif self.output == "mem":
						self.u_save[:,:,self.i_save] = self.u
						self.v_save[:,:,self.i_save] = self.v
						self.h_save[:,:,self.i_save] = self.h
						self.t_save[:,self.i_save] = n * self.dt
						self.i_save = self.i_save+1

				# call the Lax-Wendroff scheme to move forward one timestep
				if self.dynamic_core == "lax_wendroff":
					self.unew, self.vnew, self.hnew = LaxWendroffSphere(self.nx, self.ny, self.dx, self.dy, self.dy1, self.dy2, self.c_mid_yt, self.dphi, self.dtheta, self.dt, self.g, self.u, self.v, self.h, self.H, self.Re, self.THETA, self.F)
				elif self.dynamic_core == "lax_friedrichs":
					self.unew, self.vnew, self.hnew = LaxFriedrichsSphere(self.nx, self.ny, self.dx, self.dy, self.dy1, self.dy2, self.c_mid_yt, self.dphi, self.dtheta, self.dt, self.g, self.u, self.v, self.h, self.H, self.Re, self.THETA, self.F)

				# add viscous term to wind fields
				if self.viscous_dissipation:
					del2a, del2b, del2c = ViscousDissipationSphere(self.nx, self.ny, self.dx, self.dy1, self.unew, self.vnew, self.hnew)
					self.unew = self.unew + self.dt * self.vis * del2a[2:self.nx,2:self.ny]
					self.vnew = self.vnew + self.dt * self.vis * del2b[2:self.nx,2:self.ny]
					self.hnew = self.hnew + self.dt * self.vis * del2c[2:self.nx,2:self.ny]

				# set boundary condition
				self.u[:, 1:self.ny-1], self.v[:, 1:self.ny-1], self.h[:, 1:self.ny-1]= self.unew[self.idx,:], self.vnew[self.idx,:], self.hnew[self.idx,:]
