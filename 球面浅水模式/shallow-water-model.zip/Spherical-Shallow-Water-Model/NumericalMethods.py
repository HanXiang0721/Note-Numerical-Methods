import numpy as np

def ViscousDissipationSphere(nx, ny, dx, dy, unew, vnew, hnew):
	idx_tmp = [x for x in range(nx-2)]; idx_tmp.insert(nx-2,0); idx_tmp.insert(0,nx-3); idx_tmp.insert(nx,1); idx_tmp.insert(0,nx-4);
	idy_tmp = [y for y in range(ny-2)]; idy_tmp.insert(ny-2,0); idy_tmp.insert(0,ny-3); idy_tmp.insert(ny,1); idy_tmp.insert(0,ny-4);
	utmp = unew[idx_tmp,:]
	utmp = utmp[:,idy_tmp]
	vtmp = vnew[idx_tmp,:]
	vtmp = vtmp[:,idy_tmp]
	htmp = hnew[idx_tmp,:]
	htmp = htmp[:,idy_tmp]

	du_dx, du_dy = np.gradient(utmp)
	du_dx[1:nx+1,1:ny+1] = du_dx[1:nx+1,1:ny+1] / dx
	du_dy[1:nx+1,1:ny+1] = du_dy[1:nx+1,1:ny+1] / dy

	dv_dx, dv_dy = np.gradient(vtmp)
	dv_dx[1:nx+1,1:ny+1] = dv_dx[1:nx+1,1:ny+1] / dx
	dv_dy[1:nx+1,1:ny+1] = dv_dy[1:nx+1,1:ny+1] / dy

	dh_dx, dh_dy = np.gradient(htmp)
	dh_dx[1:nx+1,1:ny+1] = dh_dx[1:nx+1,1:ny+1] / dx
	dh_dy[1:nx+1,1:ny+1] = dh_dy[1:nx+1,1:ny+1] / dy

	du_dx2, du_dxdy = np.gradient(du_dx)
	du_dxdy, du_dy2 = np.gradient(du_dy)
	du_dx2[1:nx+1,1:ny+1] = du_dx2[1:nx+1,1:ny+1] / dx
	du_dy2[1:nx+1,1:ny+1] = du_dy2[1:nx+1,1:ny+1] / dy


	dv_dx2, dv_dxdy = np.gradient(dv_dx)
	dv_dxdy, dv_dy2 = np.gradient(dv_dy)
	dv_dx2[1:nx+1,1:ny+1] = dv_dx2[1:nx+1,1:ny+1] / dx
	dv_dy2[1:nx+1,1:ny+1] = dv_dy2[1:nx+1,1:ny+1] / dy

	dh_dx2, dh_dxdy = np.gradient(dh_dx)
	dh_dxdy, dh_dy2 = np.gradient(dh_dy)
	dh_dx2[1:nx+1,1:ny+1] = dh_dx2[1:nx+1,1:ny+1] / dx
	dh_dy2[1:nx+1,1:ny+1] = dh_dy2[1:nx+1,1:ny+1] / dy

	del2a = du_dx2 + du_dy2
	del2b = dv_dx2 + dv_dy2
	del2c = dh_dx2 + dh_dy2

	return del2a, del2b, del2c


def LaxWendroffSphere(nx, ny, dx, dy, dy1, dy2, c_mid_yt, dphi, dtheta, dt, g, u, v, h, H, Re, THETA, F):
	v1 = v * np.cos(THETA)

	# First work out mid-point values in time and space
	uh = u * h
	vh = v * h
	vh1 = v1 * h

	# continuity equation (calculate mid-point values at 0.5*dt):
	h_mid_xt = 0.5 * (h[1:nx,:] + h[0:nx-1,:]) - (0.5 * dt / (0.5 * (dx[1:nx,:] + dx[0:nx-1,:]))) * (uh[1:nx,:] - uh[0:nx-1,:])
	h_mid_yt = 0.5 * (h[:,1:ny] + h[:,0:ny-1]) - (0.5 * dt / (0.5 * (dy1[:,1:ny] + dy1[:,0:ny-1]))) * (vh1[:,1:ny] - vh1[:,0:ny-1])

	# v-phi, or u momentum equation (calculate mid-point values at 0.5*dt):
	Ux = uh * u + 0.5 * g * h * h
	Uy = uh * v1
	uh_mid_xt = 0.5 * (uh[1:nx,:] + uh[0:nx-1,:]) - (0.5 * dt / (0.5 * (dx[1:nx,:] + dx[0:nx-1,:]))) * (Ux[1:nx,:] - Ux[0:nx-1,:]) + 0.125 * dt * (F[1:nx,:] + F[0:nx-1,:]) * (vh[1:nx,:] + vh[0:nx-1,:])
	uh_mid_yt = 0.5 * (uh[:,1:ny] + uh[:,0:ny-1]) - (0.5 * dt / (0.5 * (dy1[:,1:ny] + dy1[:,0:ny-1]))) * (Uy[:,1:ny] - Uy[:,0:ny-1]) + 0.125 * dt * (F[:,1:ny] + F[:,0:ny-1]) * (vh[:,1:ny] + vh[:,0:ny-1])

	# v-theta, or v momentum equation (calculate mid-point values at 0.5*dt):
	Vx = uh * v
	# Vy = vh1.*v+0.5.*g.*h.^2.*cos(THETA);
	Vy = vh1 * v
	Vy2 = 0.5 * g * h * h
	vh_mid_xt = 0.5 * (vh[1:nx,:] + vh[0:nx-1,:]) - (0.5 * dt / (0.5 * (dx[1:nx,:] + dx[0:nx-1,:]))) * (Vx[1:nx,:] - Vx[0:nx-1,:]) - 0.125 * dt * (F[1:nx,:]+F[0:nx-1,:]) * (uh[1:nx,:] + uh[0:nx-1,:])
	vh_mid_yt = 0.5 * (vh[:,1:ny] + vh[:,0:ny-1]) - (0.5 * dt / (0.5 * (dy1[:,1:ny] + dy1[:,0:ny-1]))) * (Vy[:,1:ny] - Vy[:,0:ny-1]) - (0.5 * dt / dy2) * (Vy2[:,1:ny] - Vy2[:,0:ny-1]) - 0.125 * dt * (F[:,1:ny] + F[:,0:ny-1]) * (uh[:,1:ny] + uh[:,0:ny-1])

	# Now use the mid-point values to predict the values at the next timestep continuity:
	h_new = h[1:nx-1,1:ny-1] - (dt / (0.5 * (dx[1:nx-1,1:ny-1] + dx[0:nx-2,1:ny-1]))) * (uh_mid_xt[1:nx-1,1:ny-1] - uh_mid_xt[0:nx-2,1:ny-1]) - (dt / (0.5 * (dy1[1:nx-1,1:ny-1] + dy1[1:nx-1,0:ny-2]))) * (vh_mid_yt[1:nx-1,1:ny-1] * c_mid_yt[1:nx-1,1:ny-1] - vh_mid_yt[1:nx-1,0:ny-2] * c_mid_yt[1:nx-1,0:ny-2])

	# u-momentum equation:
	Ux_mid_xt = uh_mid_xt * uh_mid_xt / h_mid_xt + 0.5 * g * h_mid_xt * h_mid_xt
	Uy_mid_yt = uh_mid_yt * vh_mid_yt / h_mid_yt * c_mid_yt
	uh_new = uh[1:nx-1,1:ny-1] - (dt / (0.5 * (dx[1:nx-1,1:ny-1] + dx[0:nx-2,1:ny-1]))) * (Ux_mid_xt[1:nx-1,1:ny-1] - Ux_mid_xt[0:nx-2,1:ny-1]) - (dt / (0.5 * (dy1[1:nx-1,1:ny-1] + dy1[1:nx-1,0:ny-2]))) * (Uy_mid_yt[1:nx-1,1:ny-1] - Uy_mid_yt[1:nx-1,0:ny-2])

	# v-momentum equation:
	Vx_mid_xt = uh_mid_xt * vh_mid_xt / h_mid_xt
	Vy_mid_yt = vh_mid_yt * vh_mid_yt / h_mid_yt * c_mid_yt
	Vy_mid_yt2 = 0.5 * g * h_mid_yt * h_mid_yt
	vh_new = vh[1:nx-1,1:ny-1] - (dt / (0.5 * (dx[1:nx-1,1:ny-1] + dx[0:nx-2,1:ny-1]))) * (Vx_mid_xt[1:nx-1,1:ny-1] - Vx_mid_xt[0:nx-2,1:ny-1]) - (dt / (0.5 * (dy1[1:nx-1,1:ny-1] + dy1[1:nx-1,0:ny-2]))) * (Vy_mid_yt[1:nx-1,1:ny-1] - Vy_mid_yt[1:nx-1,0:ny-2]) - (dt / dy2) * (Vy_mid_yt2[1:nx-1,1:ny-1] - Vy_mid_yt2[1:nx-1,0:ny-2])

	# add on Coriolis and contribution of orography to pressure gradient:
	uh_new = uh_new + dt * 0.5 * (F[1:nx-1,1:ny-1] * v[1:nx-1,1:ny-1] - g * (H[2:nx,1:ny-1] - H[0:nx-2,1:ny-1]) / dx[1:nx-1,1:ny-1]) * (h[1:nx-1,1:ny-1] + h_new)
	vh_new = vh_new - dt * 0.5 * (F[1:nx-1,1:ny-1] * u[1:nx-1,1:ny-1] - g * (H[1:nx-1,2:ny] - H[1:nx-1,0:ny-2]) / dy1[1:nx-1,1:ny-1]) * (h[1:nx-1,1:ny-1] + h_new)

	# re-calculate u and v
	u_new = uh_new / h_new
	v_new = vh_new / h_new

	return u_new, v_new, h_new

def LaxFriedrichsSphere(nx, ny, dx, dy, dy1, dy2, c_mid_yt, dphi, dtheta, dt, g, u, v, h, H, Re, THETA, F):
	v1 = v * np.cos(THETA)

	uh = u * h
	vh = v * h
	vh1 = v1 * h

	h_x_next = 0.5 * (h[2:nx,1:ny-1] + h[0:nx-2,1:ny-1]) - dt / dx[1:nx-1,1:ny-1] * (uh[2:nx,1:ny-1] - uh[0:nx-2,1:ny-1])
	h_y_next = 0.5 * (h[1:nx-1,2:ny] + h[1:nx-1,0:ny-2]) - dt / dy1[1:nx-1,1:ny-1] * (vh1[1:nx-1,2:ny] - vh1[1:nx-1,0:ny-2])

	Ux = uh * u + 0.5 * g * h * h
	Uy = uh * v1
	uh_x_next = 0.5 * (uh[2:nx,1:ny-1] + uh[0:nx-2,1:ny-1]) - dt / dx[1:nx-1,1:ny-1] * (Ux[2:nx,1:ny-1] - Ux[0:nx-2,1:ny-1]) + dt * F[1:nx-1,1:ny-1] * vh[1:nx-1,1:ny-1]
	uh_y_next = 0.5 * (uh[1:nx-1,2:ny] + uh[1:nx-1,0:ny-2]) - dt / dy1[1:nx-1,1:ny-1] * (Uy[1:nx-1,2:ny] - Uy[1:nx-1,0:ny-2]) + dt * F[1:nx-1,1:ny-1] * vh[1:nx-1,1:ny-1]

	Vx = uh * v
	Vy = vh1 * v
	Vy2 = 0.5 * g * h * h
	vh_x_next = 0.5 * (vh[2:nx,1:ny-1] + vh[0:nx-2,1:ny-1]) - dt / dx[1:nx-1,1:ny-1] * (Vx[2:nx,1:ny-1] - Vx[0:nx-2,1:ny-1]) - dt * F[1:nx-1,1:ny-1] * uh[1:nx-1,1:ny-1]
	vh_y_next = 0.5 * (vh[1:nx-1,2:ny] + vh[1:nx-1,0:ny-2]) - dt / dy1[1:nx-1,1:ny-1] * (Vy[1:nx-1,2:ny] - Vy[1:nx-1,0:ny-2]) - dt / dy2 * (Vy2[1:nx-1,2:ny] - Vy2[1:nx-1,0:ny-2]) - dt * F[1:nx-1,1:ny-1] * uh[1:nx-1,1:ny-1]

	hnew = h_x_next + h_y_next
	uhnew = uh_x_next + uh_y_next + dt * 0.5 * (F[1:nx-1,1:ny-1] * v[1:nx-1,1:ny-1] - g * (H[2:nx,1:ny-1] - H[0:nx-2,1:ny-1]) / dx[1:nx-1,1:ny-1]) * (h[1:nx-1,1:ny-1] + hnew)
	vhnew = vh_x_next + vh_y_next - dt * 0.5 * (F[1:nx-1,1:ny-1] * u[1:nx-1,1:ny-1] - g * (H[1:nx-1,2:ny] - H[1:nx-1,0:ny-2]) / dy1[1:nx-1,1:ny-1]) * (h[1:nx-1,1:ny-1] + hnew)

	unew = uhnew / hnew
	vnew = vhnew / hnew

	return unew, vnew, hnew
