import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
from matplotlib import cm

def myplot(nx, ny, dx, dy, u, v, h, phi, theta, i_save):

	curl = np.zeros([nx, ny])
	#curl[1:nx-1,1:ny-1] = (u[1:nx-1,0:ny-2]-u[1:nx-1,2:ny]) / (dy[1:nx-1,0:ny-2]+dy[1:nx-1,2:ny]) + (v[2:nx,1:ny-1]-v[0:nx-2,1:ny-1]) / (dx[2:nx,1:ny-1]+dx[0:nx-2,1:ny-1])
	#curl = curl * 1e5
	curl[1:nx-1,1:ny-1] = (u[1:nx-1,0:ny-2]-u[1:nx-1,2:ny]) + (v[2:nx,1:ny-1]-v[0:nx-2,1:ny-1]) 
	#ply_phi=np.append(phi,6.28318531)
	#plt_idx = [x for x in range(nx)]
	#plt_idx.append(0)

	#plt_curl = curl[plt_idx,:]

	#PLT_THETA, PLT_PHI                = np.meshgrid(theta,ply_phi)
	PLT_THETA, PLT_PHI                = np.meshgrid(theta,phi)
	fig = plt.figure(0)
	map = Basemap(projection='ortho',lon_0=0,lat_0=0,resolution='l')
	x, y = map(PLT_PHI*180./np.pi, PLT_THETA*180./np.pi)
	map.drawmeridians(np.arange(0,360,30))
	map.drawparallels(np.arange(-90,90,30))
	#clevs = [x for x in range(-15,16,1)]
	clevs = np.linspace(-15,15,100)
	cs = map.contourf(x,y,curl,levels=clevs,cmap=cm.coolwarm)
	#cs = map.contourf(x,y,curl,cmap=cm.coolwarm)
	cbar = map.colorbar(cs,location='bottom',pad="5%")
	
	plt.savefig("./%s.png" % (i_save))
	plt.close(0)